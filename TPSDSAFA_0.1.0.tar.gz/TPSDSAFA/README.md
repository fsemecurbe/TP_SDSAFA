# Traitement des anomalies dans une relation linéaire

L'objectif du TP est d'assister les chargés d'enquête responsables du redressement de données liées par une relation linéaire de type volume - valeur. En utilisant un exemple fictif, on génère un prix moyen robuste qui n'est pas influencé de manière significative par des valeurs aberrantes. Ce prix moyen peut ensuite être appliqué pour traiter les cas de non-réponse ou les valeurs atypiques.
